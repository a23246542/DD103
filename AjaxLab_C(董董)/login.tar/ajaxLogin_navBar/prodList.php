<!DOCTYPE html>
<html>
<head>
<meta charset="utf-8">
<title>董董購物網</title>
<link rel="stylesheet" type="text/css" href="jsLogin.css">
<link rel="icon" href="大頭照.jpg">
<script type="text/javascript" src="login.js"></script>
</head>

<body>
<?php 
	require_once("navBar.inc");
 ?>
<!-- wrapper -->
<div id="wrapper">

	<!------------ content ------------>
	<div id="content">
	<center><h1>商品專區</h1></center><br><br>

	<p>俗擱大碗</p>
	<p>俗擱大碗</p>
	<p>俗擱大碗</p>
	<p>俗擱大碗</p>
	<p>俗擱大碗</p>
	<p>俗擱大碗</p>

	<a href="index.php"> 回首頁 </a><br>
	</div>
	<!------------ footer ------------>
	<div id="footer"></div>

</div>

</body>
</html>
