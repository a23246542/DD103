<!DOCTYPE html>
<html>
<head>
<meta charset="utf-8">
<title>董董購物網</title>
<link rel="stylesheet" type="text/css" href="jsLogin.css">
<link rel="icon" href="大頭照.jpg">
<script type="text/javascript" src="login.js"></script>
</head>

<body>
<?php 
	require_once("navBar.inc");
 ?>
	<!------------ content ------------>
	<div id="content">
	<center><h1>這是首頁</h1></center><br><br>

	<a href="prodList.php"> 商品專區 </a><br>
	<a href="discuss.php"> 討論專區 </a><br>
	</div>
	<!------------ footer ------------>
	<div id="footer"></div>

</div>
<script type="text/javascript">

</script>
</body>
</html>
