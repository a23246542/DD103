<!DOCTYPE html>
<html>
<head>
<meta charset="utf-8">
<title>董董購物網</title>
<link rel="stylesheet" type="text/css" href="jsLogin.css">
<link rel="icon" href="大頭照.jpg">
<script type="text/javascript" src="login.js"></script>
</head>

<body>
<?php 
	require_once("navBar.inc");
 ?>

<!-- wrapper -->
<div id="wrapper">

	<!------------ content ------------>
	<div id="content">
	<center><h1>討論專區</h1></center><br><br>

	<a href="index.php"> 回首頁 </a><br>

	<p>文章 111111111111</p>
	<p>文章 22222222222222222</p>
	<p>文章 33333333333</p>
	<p>文章 4444444444444444444444444</p>
	<p>文章 555555555555</p>
	</div>
	<!------------ footer ------------>
	<div id="footer"></div>

</div>

</body>
</html>
