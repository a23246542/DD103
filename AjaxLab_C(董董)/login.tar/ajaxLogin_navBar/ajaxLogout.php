<?php 
session_start();
unset($_SESSION["memNo"]);
unset($_SESSION["memId"]);
unset($_SESSION["memName"]);
unset($_SESSION["email"]);
unset($_SESSION["tel"]);
unset($_SESSION["birthday"]);

// session_destroy();
 ?>