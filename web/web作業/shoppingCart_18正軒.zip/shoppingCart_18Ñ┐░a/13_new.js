var storage = sessionStorage;
function doFirst(){
    var itemString = storage.getItem('addItemList');
    var items = itemString.substr(0, itemString.length-2).split(', ');

    newDiv = document.createElement('div');
    newTable = document.createElement('table');
    newDiv.appendChild(newTable);
    document.getElementById('cartList').appendChild(newDiv);

    total = 0;
    for(var key in items){
        var iteminfo = storage.getItem(items[key]);
        createCartList(items[key], iteminfo);

        var price = parseInt(iteminfo.split('|')[2]);
        total += price;
    }

    document.getElementById('total').innerText = total;
}

function createCartList(itemId, itemValue){
    // console.log(`itemId: ${itemId} | itemValue: ${itemValue}`);
    var itemTitle = itemValue.split('|')[0];
    var itemImage = 'imgs/' + itemValue.split('|')[1];
    var itemPrice = parseInt(itemValue.split('|')[2]);

    // build list section -> tr
    var tr = document.createElement('tr');
    tr.className = "item";
    // tr.setAttribute('class', 'item');
    newTable.append(tr);

    // build img -> td1
    var td1 = document.createElement('td');
    td1.style.width = `200px`;
    var img = document.createElement('img');
    img.src = itemImage;
    img.width = 70;

    td1.appendChild(img);
    tr.appendChild(td1);

    // build name&del -> td2
    var td2 = document.createElement('td');
    td2.style.width = `145px`;
    td2.id = itemId;

    var pTitle = document.createElement('p');
    pTitle.innerText = itemTitle;

    var del = document.createElement('button');
    del.innerText = "Delete";
    del.addEventListener('click', delItem, false);

    td2.appendChild(pTitle);
    td2.appendChild(del);

    tr.appendChild(td2);

    // build price -> td3
    var td3 = document.createElement('td');
    td3.style.width = `145px`;
    td3.innerText = itemPrice;

    tr.appendChild(td3);

    // build subtotal -> tds
    var tds = document.createElement('td');
    tds.style.width = `145px`;
    tds.innerText = itemPrice;

    tr.appendChild(tds);

    // build amount -> td4
    var td4 = document.createElement('td');
    td4.style.width = `145px`;

    var itemCount = document.createElement('input');
    itemCount.type = 'number';
    itemCount.value = 1;
    itemCount.min = 0;
    itemCount.addEventListener('input', changeItemCount, false);

    td4.appendChild(itemCount);
    tr.appendChild(td4);
}

function delItem(){
    let itemId = this.parentNode.getAttribute('id');
    //minus money
    var itemValue = storage.getItem(itemId);
    total -= parseInt(itemValue.split('|')[2]);
    document.getElementById('total').innerText = total;
    //clear storage
    storage.removeItem(itemId);
    storage['addItemList'] = storage['addItemList'].replace(`${itemId}, `, '');
    //del dom
    this.parentNode.parentNode.parentNode.removeChild(this.parentNode.parentNode);
}

function changeItemCount(){
    //change subtotal
    let amount = this.value;
    let before = this.parentNode.previousSibling.innerText;
    this.parentNode.previousSibling.innerText = this.parentNode.previousSibling.previousSibling.innerText * amount;
    let after = this.parentNode.previousSibling.innerText;

    //change total
    let diff = after - before;
    document.getElementById('total').innerText = parseInt(document.getElementById('total').innerText) + diff;
}

window.addEventListener('load',doFirst);