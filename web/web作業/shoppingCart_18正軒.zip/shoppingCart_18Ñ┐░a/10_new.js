var storage = sessionStorage;
function doFirst(){
    if(storage['addItemList'] == null){
        // storage['addItemList'] = '';
        storage.setItem('addItemList', '');
    }else{

    }
    var lists = document.querySelectorAll('.addButton');
    for(var i=0; i<lists.length; i++){
        lists[i].addEventListener('click', function(){
            var bearInfo = document.querySelector(`#${this.id} input`).value;
            addItem(this.id, bearInfo);
        }, false);
    }
}

function addItem(itemId, itemValue){
    // console.log(`itemId: ${itemId} | itemValue: ${itemValue}`);
    let img = document.createElement('img');
    img.src = 'imgs/' + itemValue.split('|')[1];
    // console.log(img.src);

    var title = document.createElement('span');
    title.innerText = itemValue.split('|')[0];

    var price = document.createElement('span');
    price.innerText = itemValue.split('|')[2];

    //Daddy
    var newItem = document.getElementById('newItem');

    // object exist?
    if(newItem.hasChildNodes()){
        while(newItem.childNodes.length >= 1){
            newItem.removeChild(newItem.firstChild);
        }
    }

    newItem.appendChild(img);
    newItem.appendChild(title);
    newItem.appendChild(price);

    //storage
    if(storage[itemId]){
        alert('You have this one.');
    }else{
        storage['addItemList'] += `${itemId}, `;
        storage[itemId] = itemValue;
    }

    //count amount and total
    var itemString = storage.getItem('addItemList');
    var items = itemString.substr(0, itemString.length-2).split(', ');

    var subtotal = 0;
    for(var key in items){
        var itemInfo = storage.getItem(items[key]);
        var itemPrice = parseInt(itemInfo.split('|')[2]);

        subtotal += itemPrice;
    }

    document.getElementById('itemCount').innerText = items.length;
    document.getElementById('subtotal').innerText = subtotal;
}

window.addEventListener('load',doFirst);