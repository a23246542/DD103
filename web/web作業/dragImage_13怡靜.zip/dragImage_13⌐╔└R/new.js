function init(){
    console.log('init');
    document.getElementById('dropzone').ondragover = dragOver;
    document.getElementById('dropzone').ondrop = dropped;

    setting = {
        rotate: 0,
        scale: 1,
        rotateAmount: 15,
        scaleAmount: 1
    };

    document.getElementById('scaleMinus').onclick = scaleMinus;
    document.getElementById('scalePlus').onclick = scalePlus;
    document.getElementById('rotateClock').onclick = rotateClock;
    document.getElementById('rotateClockWise').onclick = rotateClockWise;
    document.getElementById('delete').onclick = deleteImg;
}

function scaleMinus(){
    document.querySelector('img').style.transform = `rotateZ(${setting.rotate}deg) scale(${setting.scale - setting.scaleAmount})`;
    setting.scale -= setting.scaleAmount;
}

function scalePlus(){
    document.querySelector('img').style.transform = `rotateZ(${setting.rotate}deg) scale(${setting.scale + setting.scaleAmount})`;
    setting.scale += setting.scaleAmount;
}
function rotateClock(){
    document.querySelector('img').style.transform = `rotateZ(${setting.rotate + setting.rotateAmount}deg) scale(${setting.scale})`;
    setting.rotate += setting.rotateAmount;
}
function rotateClockWise(){
    document.querySelector('img').style.transform = `rotateZ(${setting.rotate - setting.rotateAmount}deg) scale(${setting.scale})`;
    setting.rotate -= setting.rotateAmount;
}
function deleteImg(){
    document.getElementById('dropzone').innerHTML = '';
}

function dragOver(e){
    e.preventDefault();
}
function dropped(e){
    e.preventDefault();
    let files = e.dataTransfer.files;
    let readFile = new FileReader();

    for(var i=0; i<files.length; i++){
        readFile.readAsDataURL(files[i]);
        readFile.addEventListener('load', function(){
            //動態新增<img>
            let img = document.createElement('img');
            img.src = this.result;
            
            document.getElementById('dropzone').insertBefore(img, dropzone.firstChild);
        }, false);
    }
}

window.addEventListener('load', init, false);