function init(){
    console.log('init');

    let canvas = document.getElementById('canvas');
    let context = canvas.getContext('2d');

    
    context.strokeStyle = 'lightblue';
    context.lineWidth = 2;
    //建立格線
    for(let i=0; i<20; i++){
        let position = i * 50;
        context.beginPath();
        context.moveTo(position, 0);
        context.lineTo(position, canvas.height);
        context.fillText(position, position, 8);
        context.stroke();
        context.beginPath();
        context.moveTo(0, position);
        context.lineTo(canvas.width, position);
        context.fillText(position, 0, position);
        context.stroke();
    }

    let radius = 200;
    let strokeStyle = '#333';
    let fillStyle = '#fff';
    let lineWidth = 5;
    let times = 0;
    eightStart(radius, strokeStyle, fillStyle, lineWidth);

    function eightStart(radius, strokeStyle, fillStyle, lineWidth){

        if(times === 0)
            context.clearRect(0, 0, canvas.width, canvas.height);
        else
            context.clearRect(-canvas.width/2, -canvas.height/2, canvas.width, canvas.height);

        //計算座標
        let axis = Math.sqrt(radius * radius / 2, 2);
    
        //紀錄八角星的座標
        let star = [
            [0, radius],
            [axis, axis],
            [radius, 0],
            [axis, -axis],
            [0, -radius],
            [-axis, -axis],
            [-radius, 0],
            [-axis, axis]
        ];
    
    
    
        //設定原點=canvas中心點
        context.strokeStyle = strokeStyle;
        context.fillStyle = fillStyle;
        context.lineWidth = lineWidth;
        if(times === 0) context.translate(canvas.width/2, canvas.height/2);
        times++;
        context.beginPath();
        let count = 0;
        for(let i=0; i<star.length; i++){
            if(i === 0){
                context.moveTo(star[i][0], star[i][1]);
            }
            //一定會落在一半的下一個(8/2+1) = 第5個
            count += 5;
            let countMode = count % 8;
            if(star[countMode] && i !== star.length-1){
                context.lineTo(star[countMode][0], star[countMode][1]);
            }else{
                context.closePath();
            }
        }
        context.stroke();
        context.fill();
    }

}

window.addEventListener('load', init, false);