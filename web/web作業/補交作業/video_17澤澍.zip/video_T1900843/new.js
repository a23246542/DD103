function init(){
    let myMovie = document.getElementById('myMovie');
    let playBtn = document.getElementById('playBtn');
    let upBtn = document.getElementById('upBtn');
    let dwnBtn = document.getElementById('dwnBtn');
    let mtdBtn = document.getElementById('mtdBtn');

    let defaultBar = document.getElementById('defaultBar');
    let progressBar = document.getElementById('progressBar');

    barSize = parseInt(window.getComputedStyle(defaultBar).width);

    playBtn.addEventListener('click', playOrPause, false);
    stopBtn.addEventListener('click', stopMovie, false);
    defaultBar.addEventListener('click', clickedBar, false);
    upBtn.addEventListener('click', soundUp, false);
    dwnBtn.addEventListener('click', soundDwn, false);
    mtdBtn.addEventListener('click', soundMt, false);
}

function soundUp(){
    console.log('soundUp');
    if(myMovie.volume < 1){
        myMovie.volume = (myMovie.volume * 10 + 1)/10;
    }
    console.log(myMovie.volume);
}

function soundDwn(){
    console.log('soundDwn');
    if(myMovie.volume > 0){
        myMovie.volume = (myMovie.volume * 10 - 1)/10;
    }
    console.log(myMovie.volume);
}

function soundMt(){
    console.log('soundMt');
    if(myMovie.volume > 0){
        soundMt.tmp = myMovie.volume;
        myMovie.volume = 0;
        mtdBtn.innerText = 'unmuted';
    }else{
        myMovie.volume = soundMt.tmp;
        mtdBtn.innerText = 'muted';
    }
    console.log(myMovie.volume);
}

function playOrPause(){
    if(!myMovie.paused && !myMovie.ended){
        myMovie.pause();
        playBtn.innerText = 'play';
    }else{
        myMovie.play();
        playBtn.innerText = 'pause';
        setInterval(update, 300);
    }
}

function update(){
    if(!myMovie.ended){
        let size = barSize / myMovie.duration * myMovie.currentTime;
        progressBar.style.width = `${size}px`;
    }else{
    }
}

function clickedBar(e){
    let mouseX = e.clientX - progressBar.offsetLeft;
    console.log(mouseX);
    progressBar.style.width = `${mouseX}px`;
    let newTime = mouseX / (barSize / myMovie.duration);
    myMovie.currentTime = newTime;
}

function stopMovie(){
    console.log('stop');
    myMovie.currentTime = 0;
    playBtn.innerText = 'play';
    myMovie.pause();
}

window.addEventListener('load', init, false);