<script>
import TodoInput from './TodoInput.vue';
import TodoItem from './TodoItem.vue';

export default {
  components: {   //local component
    TodoInput,
    TodoItem,
  },
  data(){
    return {
      todos: [],
    };
  },
  methods: {
    addTodo(item){
      this.todos.push(item);
    },
    removeTodo(index){
      this.todos.splice(index,1);
    },
  },
}
</script>

<template>
  <div>
     <!--<TodoInput @submit="addTodo"></TodoInput>-->
     <TodoInput @submit="addTodo"/>
     <ul>
        <!--<TodoItem v-for="todo in todos" :data="todo"/>-->
        <TodoItem 
            v-for="(todo,index) in todos" 
            :data="todo"
            @click.native="removeTodo(index)"/>
     </ul>
  </div>
</template>