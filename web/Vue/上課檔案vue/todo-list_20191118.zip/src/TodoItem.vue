<template>
  <li class="todo-item">
    {{data}}
  </li>
</template>

<script>
export default {
  props: ['data'],
}
</script>

<style>
    .todo-item{
        font: 24px Tahoma;
        background: #def;
        margin: 5px 0px;
        padding: 3px 10px;
        cursor: pointer;
    }
    .todo-item:hover{
        background: #fed;
    }
</style>
