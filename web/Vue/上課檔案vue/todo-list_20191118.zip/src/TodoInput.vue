<template>
    <form @submit.prevent="submit">
      <input v-model="item">
      <button>Submit</button>
    </form>
</template>

<script>
export default {
  data () {
    return {
      item: '',
    }
  },
  methods: {
    submit(){
      this.$emit('submit',this.item);
      this.item='';
    },
  },
}
</script>
