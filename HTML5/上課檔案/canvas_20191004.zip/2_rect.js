function doFirst(){
    //先跟HTML畫面產生關連，再建事件聆聽功能
    let canvas = document.getElementById('canvas');
    let context = canvas.getContext('2d');

    context.fillRect(100,100,300,200);
    // context.strokeRect(100,100,300,200);

    // context.rect(100,100,300,200);
    // context.fill();
    // context.stroke();

    context.clearRect(150,150,50,50);

    // 橡皮擦
    // context.clearRect(0,0,canvas.width,canvas.height);

}
window.addEventListener('load',doFirst);