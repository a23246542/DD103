<?php
    echo "Hello, AJAX!";
?>